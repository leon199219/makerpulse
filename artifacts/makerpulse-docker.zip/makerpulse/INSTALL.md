# Install MakerPulse in Docker Compose

English install guide. Two paths: a **standalone** stack, or **merge** into an existing Compose file.

## Requirements

| Need | Notes |
| --- | --- |
| Docker Engine 24+ | With Compose v2 (`docker compose`) |
| Disk | ~1.5 GB for the image + Postgres data |
| Outbound HTTPS | To `api.bambulab.com` / `makerworld.com` (and Telegram, if used) |
| MakerWorld user ID | Numeric UID, or set later in **Settings** |
| Free host port | Default `8080` — change the left-hand mapping if it is taken |
| Postgres | Bundled in the standalone file, or reuse yours |
| Telegram (optional) | Bot token from [@BotFather](https://t.me/BotFather) + chat ID |

You do **not** need Node.js, npm, or `node_modules` on the host. The image installs dependencies itself.

## What to copy

Unpack this project as a folder (recommended name: `makerpulse/`) on the machine that runs Compose. Keep:

- `Dockerfile`
- `docker-compose.yml` (standalone) and/or `docker-compose.merge.yml` (snippet)
- `package.json`, `package-lock.json`
- `src/`, `public/`, `scripts/`, `server/`, `migrations/`
- `vite.config.ts`, `tsconfig.json`, `.dockerignore`

Do not copy `node_modules`. Do not bind-mount the app at runtime. The only persistent volume is Postgres data.

The container always listens on **8080**. Map any host port on the left:

```yaml
ports:
  - "3001:8080"    # host 3001 → container 8080
```

---

## Path A — Standalone (new stack)

Use this when MakerPulse should have its own Compose file and its own Postgres.

1. Copy the project folder onto the Docker host, e.g. `/opt/makerpulse`.
2. Open `docker-compose.yml` and set:
   - `MAKERWORLD_UID` if you already know it
   - `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` if you want alerts
   - Host port: `"3001:8080"` or `MAKERPULSE_PORT=3001`
3. From that folder:

```bash
docker compose up -d --build
```

4. Open the UI on the host port you mapped (path `/`).
5. In **Settings**, connect your MakerWorld creator if `MAKERWORLD_UID` was empty.
6. Optional: enable the Telegram bot and send a test.

Schema is applied automatically on container start (`node scripts/migrate.mjs`).

Update later with:

```bash
docker compose up -d --build
```

---

## Path B — Merge into an existing Compose file

Use this when you already have a stack (and maybe Postgres).

1. Copy the project into a **subfolder next to your Compose file**:

```text
your-stack/
  docker-compose.yml      ← your existing file
  makerpulse/             ← this project
    Dockerfile
    src/
    …
```

2. Paste the `makerpulse` service from `docker-compose.merge.yml` into your Compose file.
3. Set `build: ./makerpulse`.
4. Set `DATABASE_URL`:
   - **Reuse your Postgres:** `postgres://USER:PASSWORD@SERVICE_NAME:5432/DBNAME`  
     `SERVICE_NAME` is the Compose service name of Postgres (not `localhost`).
   - **Add the bundled `db` service** from `docker-compose.yml` if you do not have Postgres.
5. Pick a free host port, keep `8080` on the right: `"3001:8080"`.
6. Point `depends_on` at your Postgres service (use `condition: service_healthy` if it has a healthcheck).
7. From your stack folder:

```bash
docker compose up -d --build makerpulse
```

If you reuse an existing database, the first start still runs migrations. You can also apply `migrations/0002_makerpulse.sql` yourself; re-running is safe (`_migrations` table).

---

## Environment

| Variable | Required | Description |
| --- | --- | --- |
| `DATABASE_URL` | Yes | Postgres URL |
| `MAKERWORLD_UID` | No | Numeric MakerWorld user ID (or set in UI) |
| `POLL_INTERVAL_MINUTES` | No | Default `30`, minimum `5` |
| `TELEGRAM_BOT_TOKEN` | No | BotFather token |
| `TELEGRAM_CHAT_ID` | No | Chat or group ID |
| `TELEGRAM_CADENCE` | No | `hourly` \| `every_6h` \| `daily` \| `weekly` |
| `CRON_SECRET` | No | Protects `GET /api/cron` |
| `MAKERPULSE_PORT` | No | Host port for the standalone file (default `8080`) |

Creator and Telegram can always be configured in **Settings** after start.

## Reverse proxy

Point the proxy at `makerpulse:8080` on the Compose network. Do not change the container port.

```yaml
# Traefik example labels — host port mapping can be omitted
labels:
  - traefik.enable=true
  - traefik.http.routers.makerpulse.rule=Host(`pulse.example.com`)
  - traefik.http.services.makerpulse.loadbalancer.server.port=8080
```

## Check that it is up

- UI: `/`
- Liveness: `GET /api/health`
- Stats JSON: `GET /api/stats`

## Notes

- Points are estimated from public MakerWorld data.
- Switching creator in Settings starts a fresh history. **Reset data** wipes leftover demo snapshots.
