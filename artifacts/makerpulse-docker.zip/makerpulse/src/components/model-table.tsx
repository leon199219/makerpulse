import { Link } from "@tanstack/react-router";
import { METRIC_LABELS, MODEL_METRICS } from "@/lib/metrics";
import { formatDelta, formatExact } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import type { ModelRow } from "@/lib/dashboard-types";

export function ModelTable({ models }: { models: ModelRow[] }) {
  if (models.length === 0) {
    return (
      <p className="px-1 py-8 text-sm text-muted-foreground">
        Models appear after the first successful sync.
      </p>
    );
  }

  return (
    <div className="w-full min-w-0 max-w-full overflow-x-auto">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead>
          <tr className="border-b border-border text-xs text-muted-foreground">
            <th className="py-3 pr-3 font-medium">Model</th>
            {MODEL_METRICS.map((metric) => (
              <th key={metric} className="py-3 px-2 font-medium">
                {METRIC_LABELS[metric]}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {models.map((model) => (
            <tr key={model.designId} className="border-b border-border/70 last:border-0">
              <td className="py-3 pr-3">
                <Link
                  to="/models/$designId"
                  params={{ designId: model.designId }}
                  className="flex items-center gap-3 hover:text-primary"
                >
                  {model.coverUrl ? (
                    <img
                      src={model.coverUrl}
                      alt=""
                      className="size-10 rounded-md object-cover outline outline-1 -outline-offset-1 outline-white/10"
                    />
                  ) : (
                    <span className="size-10 rounded-md bg-secondary" />
                  )}
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{model.title}</span>
                    <span className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                      {model.exclusive ? <Badge tone="accent">Exclusive</Badge> : null}
                    </span>
                  </span>
                </Link>
              </td>
              {MODEL_METRICS.map((metric) => {
                const delta = model.deltas[metric];
                return (
                  <td key={metric} className="px-2 py-3 align-top">
                    <div className="font-mono tabular-nums">{formatExact(model.stats[metric])}</div>
                    <div
                      className={
                        delta > 0
                          ? "text-xs text-success"
                          : delta < 0
                            ? "text-xs text-destructive"
                            : "text-xs text-muted-foreground"
                      }
                    >
                      {formatDelta(delta)}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
