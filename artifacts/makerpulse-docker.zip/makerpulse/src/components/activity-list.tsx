import { formatDistanceToNow } from "date-fns";
import { METRIC_LABELS } from "@/lib/metrics";
import { asDate, formatDelta, formatExact } from "@/lib/utils";
import type { EventRow } from "@/lib/dashboard-types";

export function ActivityList({ events }: { events: EventRow[] }) {
  if (events.length === 0) {
    return (
      <p className="py-8 text-sm text-muted-foreground">
        No changes in this period. Sync again after MakerWorld numbers move.
      </p>
    );
  }

  return (
    <ul className="divide-y divide-border">
      {events.map((event) => (
        <li key={event.id} className="flex items-start justify-between gap-4 py-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">
              {event.title ?? "Account"} · {METRIC_LABELS[event.metric]}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {formatExact(event.previous)} → {formatExact(event.current)} ·{" "}
              {formatDistanceToNow(asDate(event.detectedAt), { addSuffix: true })}
            </p>
          </div>
          <span
            className={
              event.delta > 0
                ? "font-mono text-sm tabular-nums text-success"
                : event.delta < 0
                  ? "font-mono text-sm tabular-nums text-destructive"
                  : "font-mono text-sm tabular-nums text-muted-foreground"
            }
          >
            {formatDelta(event.delta)}
          </span>
        </li>
      ))}
    </ul>
  );
}
