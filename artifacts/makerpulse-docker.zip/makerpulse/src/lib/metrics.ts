export const METRICS = [
  "likes",
  "collections",
  "prints",
  "downloads",
  "comments",
  "boosts",
  "followers",
  "points",
] as const;

export type Metric = (typeof METRICS)[number];

export const METRIC_LABELS: Record<Metric, string> = {
  likes: "Likes",
  collections: "Collections",
  prints: "Prints",
  downloads: "Downloads",
  comments: "Comments",
  boosts: "Boosts",
  followers: "Followers",
  points: "Est. points",
};

export const ACCOUNT_METRICS: Metric[] = [...METRICS];
export const MODEL_METRICS: Metric[] = [
  "likes",
  "collections",
  "prints",
  "downloads",
  "comments",
  "boosts",
  "points",
];

export type PeriodKey = "24h" | "7d" | "30d" | "90d" | "all";

export const PERIODS: { key: PeriodKey; label: string; days: number | null }[] = [
  { key: "24h", label: "24h", days: 1 },
  { key: "7d", label: "7D", days: 7 },
  { key: "30d", label: "30D", days: 30 },
  { key: "90d", label: "90D", days: 90 },
  { key: "all", label: "All", days: null },
];

export function periodStart(period: PeriodKey, now = new Date()): Date | null {
  const match = PERIODS.find((p) => p.key === period);
  if (!match || match.days == null) return null;
  return new Date(now.getTime() - match.days * 24 * 60 * 60 * 1000);
}

export type StatBlock = Record<Metric, number>;

export const EMPTY_STATS: StatBlock = {
  likes: 0,
  collections: 0,
  prints: 0,
  downloads: 0,
  comments: 0,
  boosts: 0,
  followers: 0,
  points: 0,
};

export function estimatePoints(input: {
  prints: number;
  boosts: number;
  exclusive?: boolean;
}): number {
  const base = input.prints * 2 + input.boosts;
  return Math.round(input.exclusive ? base * 1.25 : base);
}
