import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { ModelTable } from "@/components/model-table";
import { PeriodPicker } from "@/components/period-picker";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { loadDashboard } from "@/lib/dashboard";
import type { PeriodKey } from "@/lib/metrics";

export const Route = createFileRoute("/models/")({
  loader: () => loadDashboard({ data: { period: "7d" } }),
  component: ModelsPage,
});

function ModelsPage() {
  const [period, setPeriod] = useState<PeriodKey>("7d");
  const [q, setQ] = useState("");
  const initial = Route.useLoaderData();
  const dash = useQuery({
    queryKey: ["dashboard", period],
    queryFn: () => loadDashboard({ data: { period } }),
    initialData: period === "7d" ? initial : undefined,
  });
  const models = useMemo(() => {
    const list = dash.data?.models ?? [];
    const needle = q.trim().toLowerCase();
    if (!needle) return list;
    return list.filter((m) => m.title.toLowerCase().includes(needle));
  }, [dash.data, q]);

  return (
    <AppShell>
      <div className="flex min-w-0 flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-medium tracking-tight">Models</h1>
          <p className="text-sm text-muted-foreground">Per-model stats and change over the selected period.</p>
        </div>
        <PeriodPicker value={period} onChange={setPeriod} />
      </div>
      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Filter models"
        aria-label="Filter models"
      />
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">{models.length} published</CardTitle>
        </CardHeader>
        <CardContent>
          <ModelTable models={models} />
        </CardContent>
      </Card>
    </AppShell>
  );
}
