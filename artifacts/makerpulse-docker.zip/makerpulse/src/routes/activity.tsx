import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { ActivityList } from "@/components/activity-list";
import { PeriodPicker } from "@/components/period-picker";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { loadDashboard } from "@/lib/dashboard";
import type { PeriodKey } from "@/lib/metrics";

export const Route = createFileRoute("/activity")({
  loader: () => loadDashboard({ data: { period: "7d" } }),
  component: ActivityPage,
});

function ActivityPage() {
  const [period, setPeriod] = useState<PeriodKey>("7d");
  const initial = Route.useLoaderData();
  const dash = useQuery({
    queryKey: ["dashboard", period],
    queryFn: () => loadDashboard({ data: { period } }),
    initialData: period === "7d" ? initial : undefined,
  });

  return (
    <AppShell>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-medium tracking-tight">Activity</h1>
          <p className="text-sm text-muted-foreground">Every detected change across the account and each model.</p>
        </div>
        <PeriodPicker value={period} onChange={setPeriod} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Change log</CardTitle>
        </CardHeader>
        <CardContent>
          <ActivityList events={dash.data?.events ?? []} />
        </CardContent>
      </Card>
    </AppShell>
  );
}
